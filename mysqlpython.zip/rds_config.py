#config file containing credentials for rds mysql instance
db_username = ""
db_password = ""
db_name = "" 