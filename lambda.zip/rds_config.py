#config file containing credentials for rds mysql instance
db_username = "mysqladmin"
db_password = "08121a15^4A"
db_name = "mysqls3" 